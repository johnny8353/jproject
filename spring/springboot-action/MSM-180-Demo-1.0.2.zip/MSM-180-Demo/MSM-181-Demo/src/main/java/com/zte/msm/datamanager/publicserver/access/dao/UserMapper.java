package com.zte.msm.datamanager.publicserver.access.dao;

import java.util.List;
import java.util.Map;

import com.zte.msm.datamanager.publicserver.access.vo.UserVO;

public interface UserMapper
{
    List<UserVO> getList(Map<String, Object> map);

    int delete(Long id);

    int insert(UserVO record);

    UserVO get(Long id);

    int update(UserVO record);

}
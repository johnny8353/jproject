package com.zte.msm.datamanager.publicserver.business;



import java.util.List;
import java.util.Map;

import com.zte.html5.frame.common.PageRows;
import com.zte.msm.datamanager.publicserver.model.User;

/**
 *服务接口类 
 */
public interface UserService
{
	
	public User get(Long id) throws Exception;
	
	public List<User> getList(Map<String, Object> map, String orderField, String order) throws Exception;
	
	public int delete(Long id) throws Exception;
	
	public int insert(User entity) throws Exception;
	
	public int update(User entity) throws Exception;
	
	public PageRows<User> getPage(Map<String, Object> map, String orderField, String order, Long page, Long rows) throws Exception;
	
}
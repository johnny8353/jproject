package com.zte.test;

import com.zte.itp.jetty.JettyStartEmbedded;

public class Start
{
    public static void main(String[] args) throws Exception
    {
        //Eclipse
        new JettyStartEmbedded(8080, "demo", System.getProperty("user.dir") + "/src/main/webapp").start();

        //IDEA
        //new JettyStartEmbedded(8080, "demo", System.getProperty("user.dir") + "/MSM-181-Demo/src/main/webapp").start();
    }
}


if (process.env.INSTALL_BOWER === 'true') {
   require("bower").commands.install();
}

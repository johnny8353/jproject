package com.johnny.monitor.business.service;

import com.johnny.common.business.service.HibernateBaseService;
import com.johnny.monitor.access.vo.SystemInfoVO;

public interface SystemInfoService extends HibernateBaseService<SystemInfoVO> {

}

/**
 * CMS_APP_SyncContractInfoServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.johnny.monitor.business.webservice.cms;

public interface CMS_APP_SyncContractInfoServicePortType extends java.rmi.Remote {
    public com.johnny.monitor.business.webservice.cms.CMS_APP12_GetShipmentsDtailsResponse getShipmentsDtails(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP10_GetReceiptOutlineResponse getReceiptOutline(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP04_GetConDeliveryTermsInfoResponse getConDeliveryTermsInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP08_GetCustomerConInfoResponse getCustomerConInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP10_GetReceiptInfoListResponse getReceiptInfoList(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP14_GetContractOutlineResponse getContractOutline(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP17_GetPrjContractInfoResponse getProjectToContractSum(com.johnny.monitor.business.webservice.cms.CMS_APP_ContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP03_GetContractPayTermsInfoResponse getContractPayTermsInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP11_GetShipmentsInfoListResponse getShipmentsOutline(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP13_GetContractMainInfoResponse getContractMainInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP05_GetAfterSalesTermsInfoResponse getAfterSalesTermsInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP11_GetShipmentsInfoListResponse getShipmentsInfoList(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP18_GetContractStatusListResponse getContractStatusList(com.johnny.monitor.business.webservice.cms.CMS_APP18_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP01_SearchContractInfoResponse searchContractInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP06_GetContractProgressInfoResponse getContractProgressInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP09_GetInvoiceOutlineResponse getInvoiceOutline(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP15_GetRoleMemberResponse getRoleMember(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP17_GetPrjContractInfoResponse getProjectToContractList(com.johnny.monitor.business.webservice.cms.CMS_APP_ContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP09_GetInvoiceInfoListResponse getInvoiceInfoList(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP07_GetPrjContractInfoResponse getPrjContractInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
    public com.johnny.monitor.business.webservice.cms.CMS_APP02_GetContractBasicInfoResponse getContractBasicInfo(com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoRequest in0) throws java.rmi.RemoteException;
}

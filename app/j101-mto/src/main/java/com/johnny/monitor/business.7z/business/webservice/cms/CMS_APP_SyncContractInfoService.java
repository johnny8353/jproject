/**
 * CMS_APP_SyncContractInfoService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.johnny.monitor.business.webservice.cms;

public interface CMS_APP_SyncContractInfoService extends javax.xml.rpc.Service {
    public java.lang.String getCMS_APP_SyncContractInfoServiceHttpPortAddress();

    public com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoServicePortType getCMS_APP_SyncContractInfoServiceHttpPort() throws javax.xml.rpc.ServiceException;

    public com.johnny.monitor.business.webservice.cms.CMS_APP_SyncContractInfoServicePortType getCMS_APP_SyncContractInfoServiceHttpPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}

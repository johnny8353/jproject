/**
 * SMS_M05_PageInquiryFreightTransportInfoSrv.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.johnny.monitor.business.webservice.sms;

public interface SMS_M05_PageInquiryFreightTransportInfoSrv extends java.rmi.Remote {
    public com.johnny.monitor.business.webservice.sms.SMS_M05_PageInquiryFreightTransportInfoSrvResponse process(com.johnny.monitor.business.webservice.sms.SMS_M05_PageInquiryFreightTransportInfoSrvRequest payload) throws java.rmi.RemoteException;
}

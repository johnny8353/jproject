/**
 * HOL_M03_PageInquirProjBonusDetailInfoSrv_ep.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.johnny.monitor.business.webservice.hr;

public interface HOL_M03_PageInquirProjBonusDetailInfoSrv_ep extends javax.xml.rpc.Service {
    public java.lang.String getHOL_M03_PageInquirProjBonusDetailInfoSrv_ptAddress();

    public com.johnny.monitor.business.webservice.hr.HOL_M03_PageInquirProjBonusDetailInfoSrv getHOL_M03_PageInquirProjBonusDetailInfoSrv_pt() throws javax.xml.rpc.ServiceException;

    public com.johnny.monitor.business.webservice.hr.HOL_M03_PageInquirProjBonusDetailInfoSrv getHOL_M03_PageInquirProjBonusDetailInfoSrv_pt(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}

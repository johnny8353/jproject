(function() {
  'use strict';

  /**
   * @ngdoc overview
   * @name ngAside
   * @description
   * Main module for aside component.
   * @function
   * @author İsmail Demirbilek
   */
  angular.module('ngAside', ['ui.bootstrap.modal']);
})();

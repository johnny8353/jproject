angular.module('mgo-angular-wizard', ['templates-angularwizard']);
